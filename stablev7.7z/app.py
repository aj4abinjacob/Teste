import eel
import os
import pandas as pd
from glob import glob
from tkinter import Tk
from tkinter import filedialog

eel.init('web')

selected_files = []  # Store selected file paths
cancel_flag = False  # Flag to indicate if saving process should be cancelled

@eel.expose
def get_file_list():
    return selected_files

@eel.expose
def add_new_files():
    root = Tk()
    root.wm_attributes("-topmost", 1)
    root.withdraw()
    file_paths = filedialog.askopenfilenames(filetypes=[("CSV files", "*.csv")], initialdir=os.getcwd())
    added_files = []
    for file_path in file_paths:
        if file_path not in selected_files:
            selected_files.append(file_path)
            added_files.append(file_path)
    root.destroy()
    return added_files

@eel.expose
def get_columns(file_path):
    try:
        if file_path in selected_files:
            df = pd.read_csv(file_path, nrows=1)
            return df.columns.tolist()
        else:
            print(f"File not found: {file_path}")
            return []
    except Exception as e:
        print(f"Error reading file {file_path}: {str(e)}")
        return []

@eel.expose
def remove_file(file_path):
    if file_path in selected_files:
        selected_files.remove(file_path)
        return True
    else:
        print(f"File not found: {file_path}")
        return False

@eel.expose
def cancel_saving():
    global cancel_flag
    cancel_flag = True

def combine_files(final_columns, selections):
    global cancel_flag
    cancel_flag = False
    combined_df = pd.DataFrame()

    # Count unique files
    unique_files = set()
    for file_columns in selections.values():
        unique_files.update(file_columns.keys())
    total_files = len(unique_files)
    
    processed_files = set()
    file_dataframes = {}

    for file_path in unique_files:
        if cancel_flag:
            eel.update_progress("Process cancelled by user.")
            return None

        try:
            if file_path not in processed_files:
                eel.update_progress(f"Processing file: {os.path.basename(file_path)}")
                processed_files.add(file_path)
                eel.update_progress(f"Processed {len(processed_files)} out of {total_files} files")
                
                # Read the file once and store the DataFrame
                df = pd.read_csv(file_path, low_memory=False)
                df['File Path'] = file_path  # Add 'File Path' column
                file_dataframes[file_path] = df

        except Exception as e:
            eel.update_progress(f"Error processing file {file_path}: {str(e)}")
            return None

    # Now process the columns using the stored DataFrames
    for final_column in final_columns:
        if final_column in selections:
            for file_path, columns in selections[final_column].items():
                if cancel_flag:
                    eel.update_progress("Process cancelled by user.")
                    return None

                try:
                    df = file_dataframes[file_path]
                    
                    # Create a new column with the final column name
                    if len(columns) == 1:
                        df[final_column] = df[columns[0]]
                    else:
                        # If multiple columns, fill nulls
                        df[final_column] = df[columns[0]]
                        for col in columns[1:]:
                            df[final_column] = df[final_column].fillna(df[col])
                    
                    # Select only the required columns
                    temp_df = df[['File Path', final_column]].copy()
                    
                    # Append to the combined DataFrame
                    if combined_df.empty:
                        combined_df = temp_df
                    else:
                        combined_df = pd.concat([combined_df, temp_df], ignore_index=True)

                except Exception as e:
                    eel.update_progress(f"Error processing column {final_column} in file {file_path}: {str(e)}")

    # Ensure all final columns are present
    for col in final_columns:
        if col not in combined_df.columns:
            combined_df[col] = None

    # Reorder columns
    column_order = ['File Path'] + final_columns
    combined_df = combined_df[column_order]

    return combined_df

@eel.expose
def save_selections(selections):
    eel.update_progress("Starting file combination process...")
    
    # Combine the files
    result_df = combine_files(selections['finalColumns'], selections['selectedColumns'])
    
    if result_df is None:
        return {"success": False, "message": "Process cancelled by user."}

    eel.update_progress("File combination complete. Opening save dialog...")
    
    # Open file dialog to save the combined file
    root = Tk()
    root.wm_attributes("-topmost", 1)
    root.withdraw()
    file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], initialdir=os.getcwd())
    root.destroy()
    
    if file_path:
        eel.update_progress("Saving combined file...")
        result_df.to_csv(file_path, index=False)
        return {"success": True, "message": f"Combined file saved to: {file_path}"}
    else:
        eel.update_progress("File save cancelled by user.")
        return {"success": False, "message": "File save cancelled"}
    
def restructure_selections(final_columns, selections):
    restructured = []
    for col in final_columns:
        file_columns = {}
        if col in selections:
            for file, columns in selections[col].items():
                file_columns[file] = columns
        restructured.append((col, file_columns))
    return restructured

def select_columns():
    eel.start('index.html', size=(1200, 800))
    
    final_columns = eel.get_final_columns()()
    selections = eel.get_selections()()
    print("Selections", selections)
    
    column_mappings = restructure_selections(final_columns, selections)
    
    print("Column Mappings:", column_mappings)
    return column_mappings

if __name__ == "__main__":
    column_mappings = select_columns()
    print("Final Column Mappings:", column_mappings)