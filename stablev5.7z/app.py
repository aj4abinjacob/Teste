import eel
import os
import pandas as pd
from glob import glob
from tkinter import Tk
from tkinter import filedialog

eel.init('web')

selected_files = []  # Store selected file paths

@eel.expose
def get_file_list():
    return selected_files

@eel.expose
def add_new_files():
    root = Tk()
    root.wm_attributes("-topmost", 1)
    root.withdraw()
    file_paths = filedialog.askopenfilenames(filetypes=[("CSV files", "*.csv")], initialdir=os.getcwd())
    added_files = []
    for file_path in file_paths:
        if file_path not in selected_files:
            selected_files.append(file_path)
            added_files.append(file_path)
    root.destroy()
    return added_files

@eel.expose
def get_columns(file_path):
    try:
        if file_path in selected_files:
            df = pd.read_csv(file_path, nrows=1)
            return df.columns.tolist()
        else:
            print(f"File not found: {file_path}")
            return []
    except Exception as e:
        print(f"Error reading file {file_path}: {str(e)}")
        return []

@eel.expose
def remove_file(file_path):
    if file_path in selected_files:
        selected_files.remove(file_path)
        return True
    else:
        print(f"File not found: {file_path}")
        return False

@eel.expose
def save_selections(final_columns, selections):
    print("Final Columns:", final_columns)
    print("Selections:", selections)
    # Here you can add code to save the selections to a file or database
    return True

def restructure_selections(final_columns, selections):
    restructured = []
    for col in final_columns:
        file_columns = {}
        if col in selections:
            for file, columns in selections[col].items():
                file_columns[file] = columns
        restructured.append((col, file_columns))
    return restructured

def select_columns():
    eel.start('index.html', size=(1200, 800))
    
    final_columns = eel.get_final_columns()()
    selections = eel.get_selections()()
    print("Selections", selections)
    
    column_mappings = restructure_selections(final_columns, selections)
    
    print("Column Mappings:", column_mappings)
    return column_mappings

if __name__ == "__main__":
    column_mappings = select_columns()
    print("Final Column Mappings:", column_mappings)