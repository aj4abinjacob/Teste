let finalColumns = [];
let selectedColumns = {};
let currentFinalColumn = null;
let allColumns = [];
let currentSearchTerm = '';
let availableFiles = [];

async function init() {
    await updateFileList();
    
    document.getElementById('columnSearch').addEventListener('input', filterColumns);
    document.getElementById('addColumnBtn').addEventListener('click', addNewColumn);
    document.getElementById('submitBtn').addEventListener('click', submitSelection);

    updateFileCardHighlights();

    document.getElementById('manageFilesBtn').addEventListener('click', openManageFilesOverlay);
    document.getElementById('closeOverlayBtn').addEventListener('click', closeManageFilesOverlay);
    document.getElementById('addFileBtn').addEventListener('click', addNewFile);
}

async function updateFileList() {
    availableFiles = await eel.get_file_list()();
    displayFileList(availableFiles);
    updateManageFileList();
}

function displayFileList(fileList) {
    const fileListElement = document.getElementById('fileList');
    fileListElement.innerHTML = '';
    fileList.forEach(file => {
        const fileCard = createFileCard(file);
        fileListElement.appendChild(fileCard);
    });
}

function createFileCard(file) {
    const fileCard = document.createElement('div');
    fileCard.className = 'file-card';
    fileCard.dataset.file = file;

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'file';
    radio.value = file;
    radio.id = file;
    radio.className = 'file-radio';
    
    const label = document.createElement('label');
    label.htmlFor = file;
    label.textContent = file;
    
    fileCard.appendChild(radio);
    fileCard.appendChild(label);
    fileCard.addEventListener('click', (event) => {
        event.preventDefault();
        radio.checked = true;
        document.querySelectorAll('.file-card').forEach(card => card.classList.remove('selected'));
        fileCard.classList.add('selected');
        loadColumns(file);
    });

    return fileCard;
}

function openManageFilesOverlay() {
    document.getElementById('manageFilesOverlay').style.display = 'block';
    updateManageFileList();
}

function closeManageFilesOverlay() {
    document.getElementById('manageFilesOverlay').style.display = 'none';
}

async function addNewFile() {
    try {
        const newFiles = await eel.add_new_files()();
        if (newFiles && newFiles.length > 0) {
            await updateFileList();
            
            if (newFiles.length > 0) {
                const firstNewFile = newFiles[0];
                const fileCard = document.querySelector(`.file-card[data-file="${firstNewFile}"]`);
                if (fileCard) {
                    fileCard.click();
                }
            }
        }
    } catch (error) {
        console.error("Error adding new files:", error);
        alert("An error occurred while adding new files. Please try again.");
    }
}

function updateManageFileList() {
    const manageFileList = document.getElementById('manageFileList');
    manageFileList.innerHTML = '';
    availableFiles.forEach(file => {
        const fileCard = document.createElement('div');
        fileCard.className = 'file-card';
        
        const fileName = document.createElement('span');
        fileName.textContent = file;
        
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.className = 'remove-file-btn';
        removeBtn.addEventListener('click', () => removeFile(file));
        
        fileCard.appendChild(fileName);
        fileCard.appendChild(removeBtn);
        manageFileList.appendChild(fileCard);
    });
}

async function removeFile(file) {
    try {
        await eel.remove_file(file)();
        await updateFileList();
        
        // Remove the file from selectedColumns
        for (let column in selectedColumns) {
            delete selectedColumns[column][file];
        }
        
        // If the removed file was selected, clear the columns
        const selectedFile = document.querySelector('input[name="file"]:checked');
        if (selectedFile && selectedFile.value === file) {
            document.getElementById('columnList').innerHTML = '';
            document.getElementById('selectedColumns').innerHTML = '';
        }
        
        displaySelectedColumns();
        updateFileCardHighlights();
    } catch (error) {
        console.error("Error removing file:", error);
        alert("An error occurred while removing the file. Please try again.");
    }
}

async function loadColumns(file) {
    try {
        allColumns = await eel.get_columns(file)();
        allColumns.sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));
        filterColumns();
    } catch (error) {
        console.error("Error loading columns:", error);
        alert(`Failed to load columns for file: ${file}`);
    }
}

function filterColumns() {
    currentSearchTerm = document.getElementById('columnSearch').value.toLowerCase();
    const filteredColumns = allColumns.filter(column => 
        column.toLowerCase().includes(currentSearchTerm)
    );
    displayColumns(filteredColumns);
}

function displayColumns(columns) {
    const columnListElement = document.getElementById('columnList');
    columnListElement.innerHTML = '';
    columns.forEach(column => {
        const columnCard = document.createElement('div');
        columnCard.className = 'column-card';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.name = 'column';
        checkbox.value = column;
        checkbox.id = 'column_' + column;
        checkbox.className = 'column-checkbox';
        
        const selectedFile = document.querySelector('input[name="file"]:checked');
        if (selectedFile) {
            const isChecked = selectedColumns[currentFinalColumn] && 
                              selectedColumns[currentFinalColumn][selectedFile.value] && 
                              selectedColumns[currentFinalColumn][selectedFile.value].includes(column);
            checkbox.checked = isChecked;
            if (isChecked) {
                columnCard.classList.add('selected');
            }
        }
        
        const label = document.createElement('label');
        label.htmlFor = 'column_' + column;
        label.textContent = column;
        
        columnCard.appendChild(checkbox);
        columnCard.appendChild(label);
        columnCard.addEventListener('click', (event) => {
            event.preventDefault();
            checkbox.checked = !checkbox.checked;
            columnCard.classList.toggle('selected');
            const selectedFile = document.querySelector('input[name="file"]:checked');
            if (selectedFile) {
                updateSelectedColumns(selectedFile.value, column, checkbox.checked);
            }
        });
        
        columnListElement.appendChild(columnCard);
    });
}

function updateSelectedColumns(file, column, isSelected) {
    if (!currentFinalColumn) return;
    
    if (!selectedColumns[currentFinalColumn]) {
        selectedColumns[currentFinalColumn] = {};
    }
    if (!selectedColumns[currentFinalColumn][file]) {
        selectedColumns[currentFinalColumn][file] = [];
    }
    if (isSelected && !selectedColumns[currentFinalColumn][file].includes(column)) {
        selectedColumns[currentFinalColumn][file].push(column);
    } else if (!isSelected) {
        selectedColumns[currentFinalColumn][file] = selectedColumns[currentFinalColumn][file].filter(c => c !== column);
    }
    displaySelectedColumns();
    updateFileCardHighlights();
}

function updateFileCardHighlights() {
    const fileCards = document.querySelectorAll('.file-card');
    fileCards.forEach(card => {
        const file = card.dataset.file;
        let hasSelectedColumns = false;

        if (currentFinalColumn && selectedColumns[currentFinalColumn] && 
            selectedColumns[currentFinalColumn][file] && 
            selectedColumns[currentFinalColumn][file].length > 0) {
            hasSelectedColumns = true;
        }
        
        card.classList.toggle('has-selected-columns', hasSelectedColumns);
    });
}

function addNewColumn() {
    const newColumnInput = document.getElementById('newColumnInput');
    const newColumnName = newColumnInput.value.trim();

    if (newColumnName === '') {
        alert('No values added. Please enter a column name.');
        return;
    }

    if (finalColumns.includes(newColumnName)) {
        alert('This column already exists. Please enter a unique column name.');
        return;
    }

    finalColumns.push(newColumnName);
    newColumnInput.value = '';
    selectFinalColumn(newColumnName);
    displayFinalColumns();
    updateFileCardHighlights();

    // Update the search column with the new final column name
    const columnSearchInput = document.getElementById('columnSearch');
    columnSearchInput.value = newColumnName;
    filterColumns(); // Trigger the search with the new value
}

function selectFinalColumn(column) {
    currentFinalColumn = column;
    displayFinalColumns();
    displaySelectedColumns();
    updateFileCardHighlights();
    
    const selectedFile = document.querySelector('input[name="file"]:checked');
    if (selectedFile) {
        loadColumns(selectedFile.value);
    }
}

function displayFinalColumns() {
    const finalColumnList = document.getElementById('finalColumnList');
    finalColumnList.innerHTML = '';
    finalColumns.forEach(column => {
        const columnCard = document.createElement('div');
        columnCard.className = 'finalColumn';
        if (column === currentFinalColumn) {
            columnCard.classList.add('selected');
        }
        
        const span = document.createElement('span');
        span.textContent = column;
        columnCard.appendChild(span);
        
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.className = 'removeBtn';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            removeFinalColumn(column);
        });
        columnCard.appendChild(removeBtn);
        
        columnCard.addEventListener('click', () => selectFinalColumn(column));
        
        finalColumnList.appendChild(columnCard);
    });
}

function removeFinalColumn(column) {
    finalColumns = finalColumns.filter(c => c !== column);
    delete selectedColumns[column];
    displayFinalColumns();
    if (currentFinalColumn === column) {
        currentFinalColumn = finalColumns[0] || null;
    }
    displaySelectedColumns();
    updateFileCardHighlights();
}

function displaySelectedColumns() {
    const selectedColumnsElement = document.getElementById('selectedColumns');
    selectedColumnsElement.innerHTML = '';
    if (currentFinalColumn && selectedColumns[currentFinalColumn]) {
        const finalColumnElement = document.createElement('h3');
        finalColumnElement.textContent = currentFinalColumn;
        selectedColumnsElement.appendChild(finalColumnElement);

        const scrollableContent = document.createElement('div');
        scrollableContent.className = 'scrollable-content';

        for (const [file, columns] of Object.entries(selectedColumns[currentFinalColumn])) {
            if (columns.length > 0) {
                const fileCard = document.createElement('div');
                fileCard.className = 'file-card';
                
                const fileElement = document.createElement('div');
                fileElement.className = 'file-name';
                fileElement.textContent = file;
                fileCard.appendChild(fileElement);
                
                const columnContainer = document.createElement('div');
                columnContainer.className = 'column-container';
                
                columns.forEach(column => {
                    const columnElement = document.createElement('div');
                    columnElement.className = 'column-item';
                    columnElement.textContent = column;
                    columnContainer.appendChild(columnElement);
                });
                
                fileCard.appendChild(columnContainer);
                scrollableContent.appendChild(fileCard);
            }
        }

        selectedColumnsElement.appendChild(scrollableContent);
    }
    updateFileCardHighlights();
}

function submitSelection() {
    if (finalColumns.length === 0) {
        alert('No columns added. Please add at least one column before submitting.');
        return;
    }

    let hasSelection = false;
    for (let column in selectedColumns) {
        for (let file in selectedColumns[column]) {
            if (selectedColumns[column][file].length > 0) {
                hasSelection = true;
                break;
            }
        }
        if (hasSelection) break;
    }

    if (!hasSelection) {
        alert('No columns selected. Please select at least one column before submitting.');
        return;
    }

    eel.save_selections(finalColumns, selectedColumns)();
}

eel.expose(get_final_columns);
function get_final_columns() {
    return finalColumns;
}

eel.expose(get_selections);
function get_selections() {
    return selectedColumns;
}

init();