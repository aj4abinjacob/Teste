let finalColumns = [];
let selectedColumns = {};
let currentFinalColumn = null;
let allColumns = [];
let csvDirectory = 'data';
let currentSearchTerm = '';

async function init() {
    const fileList = await eel.get_file_list()();
    const fileListElement = document.getElementById('fileList');
    fileList.forEach(file => {
        const fileCard = document.createElement('div');
        fileCard.className = 'file-card';
        fileCard.dataset.file = file;

        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = 'file';
        radio.value = file;
        radio.id = file;
        radio.className = 'file-radio';
        
        const label = document.createElement('label');
        label.htmlFor = file;
        label.textContent = file;
        
        fileCard.appendChild(radio);
        fileCard.appendChild(label);
        fileCard.addEventListener('click', (event) => {
            event.preventDefault();
            document.querySelectorAll('.file-card').forEach(card => card.classList.remove('selected'));
            fileCard.classList.add('selected');
            radio.checked = true;
            loadColumns(file);
        });
        fileListElement.appendChild(fileCard);
    });

    document.getElementById('columnSearch').addEventListener('input', filterColumns);
    document.getElementById('addColumnBtn').addEventListener('click', addNewColumn);
    document.getElementById('submitBtn').addEventListener('click', submitSelection);

    updateFileCardHighlights();
}

function addNewColumn() {
    const newColumnInput = document.getElementById('newColumnInput');
    const newColumnName = newColumnInput.value.trim();

    if (newColumnName === '') {
        showWarning('No values added. Please enter a column name.');
        return;
    }

    if (finalColumns.includes(newColumnName)) {
        showWarning('This column already exists. Please enter a unique column name.');
        return;
    }

    finalColumns.push(newColumnName);
    newColumnInput.value = '';
    selectFinalColumn(newColumnName);
    displayFinalColumns();
    updateFileCardHighlights();

    // Update the search column with the new final column name
    const columnSearchInput = document.getElementById('columnSearch');
    columnSearchInput.value = newColumnName;
    filterColumns(); // Trigger the search with the new value
}

function submitSelection() {
    if (finalColumns.length === 0) {
        showWarning('No columns added. Please add at least one column before submitting.');
        return;
    }

    let hasSelection = false;
    for (let column in selectedColumns) {
        for (let file in selectedColumns[column]) {
            if (selectedColumns[column][file].length > 0) {
                hasSelection = true;
                break;
            }
        }
        if (hasSelection) break;
    }

    if (!hasSelection) {
        showWarning('No columns selected. Please select at least one column before submitting.');
        return;
    }

    eel.save_selections(finalColumns, selectedColumns)();
}

function showWarning(message) {
    alert(message);
}

async function loadColumns(file) {
    allColumns = await eel.get_columns(file)();
    allColumns.sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));
    filterColumns();
}

function filterColumns() {
    currentSearchTerm = document.getElementById('columnSearch').value.toLowerCase();
    const filteredColumns = allColumns.filter(column => 
        column.toLowerCase().includes(currentSearchTerm)
    );
    displayColumns(filteredColumns);
}

function displayColumns(columns) {
    const columnListElement = document.getElementById('columnList');
    columnListElement.innerHTML = '';
    columns.forEach(column => {
        const columnCard = document.createElement('div');
        columnCard.className = 'column-card';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.name = 'column';
        checkbox.value = column;
        checkbox.id = 'column_' + column;
        checkbox.className = 'column-checkbox';
        
        const selectedFile = document.querySelector('input[name="file"]:checked').value;
        const isChecked = selectedColumns[currentFinalColumn] && 
                          selectedColumns[currentFinalColumn][selectedFile] && 
                          selectedColumns[currentFinalColumn][selectedFile].includes(column);
        checkbox.checked = isChecked;
        if (isChecked) {
            columnCard.classList.add('selected');
        }
        
        const label = document.createElement('label');
        label.htmlFor = 'column_' + column;
        label.textContent = column;
        
        columnCard.appendChild(checkbox);
        columnCard.appendChild(label);
        columnCard.addEventListener('click', (event) => {
            event.preventDefault();
            checkbox.checked = !checkbox.checked;
            columnCard.classList.toggle('selected');
            updateSelectedColumns(selectedFile, column, checkbox.checked);
        });
        
        columnListElement.appendChild(columnCard);
    });
}

function updateSelectedColumns(file, column, isSelected) {
    if (!currentFinalColumn) return;
    
    if (!selectedColumns[currentFinalColumn]) {
        selectedColumns[currentFinalColumn] = {};
    }
    if (!selectedColumns[currentFinalColumn][file]) {
        selectedColumns[currentFinalColumn][file] = [];
    }
    if (isSelected && !selectedColumns[currentFinalColumn][file].includes(column)) {
        selectedColumns[currentFinalColumn][file].push(column);
    } else if (!isSelected) {
        selectedColumns[currentFinalColumn][file] = selectedColumns[currentFinalColumn][file].filter(c => c !== column);
    }
    displaySelectedColumns();
    updateFileCardHighlights();
}

function updateFileCardHighlights() {
    const fileCards = document.querySelectorAll('.file-card');
    fileCards.forEach(card => {
        const file = card.dataset.file;
        let hasSelectedColumns = false;

        // Only check the current final column
        if (currentFinalColumn && selectedColumns[currentFinalColumn] && 
            selectedColumns[currentFinalColumn][file] && 
            selectedColumns[currentFinalColumn][file].length > 0) {
            hasSelectedColumns = true;
        }
        
        card.classList.toggle('has-selected-columns', hasSelectedColumns);
    });
}

function selectFinalColumn(column) {
    currentFinalColumn = column;
    displayFinalColumns();
    displaySelectedColumns();
    updateFileCardHighlights();
    
    const selectedFile = document.querySelector('input[name="file"]:checked');
    if (selectedFile) {
        loadColumns(selectedFile.value);
    }
}

function displaySelectedColumns() {
    const selectedColumnsElement = document.getElementById('selectedColumns');
    selectedColumnsElement.innerHTML = '';
    if (currentFinalColumn && selectedColumns[currentFinalColumn]) {
        const finalColumnElement = document.createElement('h3');
        finalColumnElement.textContent = currentFinalColumn;
        selectedColumnsElement.appendChild(finalColumnElement);
        for (const [file, columns] of Object.entries(selectedColumns[currentFinalColumn])) {
            if (columns.length > 0) {
                const fileCard = document.createElement('div');
                fileCard.className = 'file-card';
                
                const fileElement = document.createElement('div');
                fileElement.className = 'file-name';
                fileElement.textContent = file;
                fileCard.appendChild(fileElement);
                
                columns.forEach(column => {
                    const columnElement = document.createElement('div');
                    columnElement.className = 'column-item';
                    columnElement.textContent = column;
                    fileCard.appendChild(columnElement);
                });
                
                selectedColumnsElement.appendChild(fileCard);
            }
        }
    }
    updateFileCardHighlights();
}

function displayFinalColumns() {
    const finalColumnList = document.getElementById('finalColumnList');
    finalColumnList.innerHTML = '';
    finalColumns.forEach(column => {
        const columnCard = document.createElement('div');
        columnCard.className = 'finalColumn';
        if (column === currentFinalColumn) {
            columnCard.classList.add('selected');
        }
        
        const span = document.createElement('span');
        span.textContent = column;
        columnCard.appendChild(span);
        
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.className = 'removeBtn';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            removeFinalColumn(column);
        });
        columnCard.appendChild(removeBtn);
        
        columnCard.addEventListener('click', () => selectFinalColumn(column));
        
        finalColumnList.appendChild(columnCard);
    });
}

function removeFinalColumn(column) {
    finalColumns = finalColumns.filter(c => c !== column);
    delete selectedColumns[column];
    displayFinalColumns();
    if (currentFinalColumn === column) {
        currentFinalColumn = finalColumns[0] || null;
    }
    displaySelectedColumns();
    updateFileCardHighlights();
}

eel.expose(get_final_columns);
function get_final_columns() {
    return finalColumns;
}

eel.expose(get_selections);
function get_selections() {
    return selectedColumns;
}

eel.expose(set_csv_directory);
function set_csv_directory(directory) {
    csvDirectory = directory;
}

init();