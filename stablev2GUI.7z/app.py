import eel
import os
import pandas as pd
from glob import glob

eel.init('web')

@eel.expose
def get_file_list():
    directory = "data"
    try:
        return glob(os.path.join(directory, "*.csv"))
    except Exception as e:
        print(f"Error getting file list: {str(e)}")
        return []

@eel.expose
def get_columns(file_path):
    try:
        df = pd.read_csv(file_path, nrows=1)
        return df.columns.tolist()
    except Exception as e:
        print(f"Error reading file {file_path}: {str(e)}")
        return []

@eel.expose
def save_selections(final_columns, selections):
    print("yes")
    print("Final Columns:", final_columns)
    print("Selections:", selections)
    return True

def restructure_selections(final_columns, selections):
    restructured = []
    for col in final_columns:
        file_columns = {}
        if col in selections:
            for file, columns in selections[col].items():
                file_columns[file] = columns
        restructured.append((col, file_columns))
    return restructured

def select_columns(directory):
    # eel.start('index.html', size=(1200, 800))
    eel.start('index.html', size=(1200, 800), maximize=True)
    
    # After eel.start (which is blocking), you can retrieve the results:
    final_columns = eel.get_final_columns()()
    selections = eel.get_selections()()
    print("Selections",selections)
    
    # Restructure the selections
    column_mappings = restructure_selections(final_columns, selections)
    
    print("Column Mappings:", column_mappings)
    return column_mappings

if __name__ == "__main__":
    directory = "data"
    column_mappings = select_columns(directory)
    print("Final Column Mappings:", column_mappings)